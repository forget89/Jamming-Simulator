

function direct_animation (data) {
        // top исправить
        console.log(data)
        const margin = ({ top: 150, right: 30, bottom: 30, left: 40 })

        data.sort(function (a, b) {
            return a.hnkt - b.hnkt
        })
        data.sort(function (a, b) {
            return a.hek - b.hek
        })
        data.sort(function (a, b) {
            return a.hnktjg - b.hnktjg
        })
        const maxHkp = d3.max(data, function (d) {
            return +d.hkp
        })
        const maxHek = d3.max(data, function (d) {
            return +d.hek
        })
        // console.log(maxHkp)
        // console.log(data)
        // for (var i = 0; i < data.length; i++) {
        //     console.log(data[i].t);
        // }
        const chart = d3.select("#chart");
        var height = maxHkp;
        var svg = d3.select("#chart")

        var yScaleAllHeihgt = d3.scaleLinear()
            .domain([d3.min(data, function (d) { return +d.hkp; }), d3.max(data, function (d) { return +d.height; })])
            .range([1, height + margin.top]);

        var y_axis = d3.axisRight()
            .scale(yScaleAllHeihgt)
            .ticks(30, "f")

        svg.append("g") // высота скважины 
            .attr("transform", "translate(180, 0)")
            .call(y_axis)
            .selectAll("text")
            .attr("dx", ".1em")
            .attr("dy", ".3em")
            .style("font-family", "Montserrat")
            .attr("transform", "rotate(0)")
            .style("font-size", "12px")
            .style("color", "white")

        var yScaleHek = d3.scaleLinear()
            .domain([d3.min(data, function (d) { return +d.hkp; }), d3.max(data, function (d) { return +d.hek; })])
            .range([margin.top + maxHkp, margin.top + maxHkp + maxHek]);

        var y_axisHek = d3.axisRight()
            .scale(yScaleHek)
            .ticks(2, "f")

        svg.append("g") // высота скважины 
            .attr("transform", "translate(150, 0)")
            .call(y_axisHek)
            .selectAll("text")
            .attr("dx", ".1em")
            .attr("dy", ".3em")
            .style("font-family", "Montserrat")
            .attr("transform", "rotate(0)")
            .style("font-size", "12px")
            .style("color", "white")

        for (var i = 0; i < data.length; i++) {
            // console.log(data[i].hnkt)
            svg.append("rect")
                .attr("x", 30)
                .attr("y", margin.top)
                .attr("width", 90)
                .attr("height", function () {
                    return data[i].hkp;
                })
                .style("fill", "rgb(184, 110, 20")

            svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return margin.top + maxHkp;
                })
                .attr("width", 90)
                .attr("height", function () {
                    return data[i].hek;
                })
                .style("fill", "rgb(184, 110, 20")

            svg.append("rect")
                .attr("x", 60)
                .attr("y", margin.top)
                .attr("width", 30)
                .attr("height", function () {
                    return data[i].hnkt;
                })
                .style("fill", "rgb(184, 110, 20")

            svg.append("rect")
                .attr("x", 28)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 120)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 150)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")
        }

        svg.append("rect")
            .attr("x", 0)
            .attr("y", 0)
            .attr("width", 150)
            .attr("height", 2)
            .style("fill", "white")

        svg.append("rect")
            .attr("x", 0)
            .attr("y", margin.top + maxHkp + maxHek - 2)
            .attr("width", 152)
            .attr("height", 3)
            .style("fill", "white")

        svg.append("rect")
            .attr("x", 30)
            .attr("y", margin.top + maxHkp + maxHek)
            .attr("width", 92)
            .attr("height", 20)
            .style("fill", "gray")



        for (var i = 1; i < data.length; i++) {
            var delay1 = i * 120; //hnkt зависит от каких данных, от кол ва массивов, у нас же прогоняется цикл, поэтому тут только меняя delay можно подогнать 1 время выполнения 
            var delay2 = i * 350; //hkp 
            var delay3 = i * 200; //hek
            // Создаем прямоугольник
            var rectAnimFirst = svg.append("rect")
                .attr("x", 60)
                .attr("y", margin.top)
                .attr("width", 30)
                .attr("height", 0) // Начальная высота 0
                .style("stroke", "black")
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay1) // Применяем задержку
                .duration(500) // Продолжительность анимации
                .attr("height", function () {
                    return data[i].hnktjg; // Изменяем высоту на значение из данных
                })

            var rectAnimSmall = svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return margin.top + maxHkp; // Начальная позиция по оси Y
                })
                .attr("width", 90)
                .attr("height", 0) // Начальная высота 0
                .style("fill", "rgb(11, 11, 100)")
                // .style("stroke", "black")
                .transition()
                .delay(delay3) // Применяем задержку
                .duration(100) // Продолжительность анимации
                .attr("height", function () {
                    return data[i].hekjg; // Изменяем высоту на значение из данных
                })

            // if (+data[i].hkpjg == maxHkp) {

            var rectAnimSecond = svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return margin.top + maxHkp - data[i].hkpjg; // Начальная позиция по оси Y
                })
                .attr("width", 30)
                .attr("height", 0) // Начальная высота 0
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay2) // Применяем задержку
                .duration(500) // Продолжительность анимации
                .attr("height", function () {
                    return data[i].hkpjg; // Изменяем высоту на значение из данных
                })

            var rectAnimSecond = svg.append("rect")
                .attr("x", 90)
                .attr("y", function () {
                    return margin.top + maxHkp - data[i].hkpjg; // Начальная позиция по оси Y
                })
                .attr("width", 30)
                .attr("height", 0) // Начальная высота 0
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay2) // Применяем задержку
                .duration(500) // Продолжительность анимации
                .attr("height", function () {
                    return data[i].hkpjg; // Изменяем высоту на значение из данных
                })
            // Добавляем задержку перед началом анимации прямоугольника hekjg
            // rectAnimSecond.transition().delay(data.length * 500).duration(500);???
            // }

        }
    }
    


function back_animation(data) {
        const margin = ({ top: 200, right: 30, bottom: 30, left: 40 })

        data.sort(function (a, b) {
            return a.hnkt - b.hnkt
        })
        data.sort(function (a, b) {
            return a.hek - b.hek
        })
        data.sort(function (a, b) {
            return a.hnktjg - b.hnktjg
        })
        const maxHkp = d3.max(data, function (d) {
            return +d.hkp
        })
        const maxHkpjg = d3.max(data, function (d) {
            return +d.hkpjg
        })
        const maxHnkt = d3.max(data, function (d) {
            return +d.hnkt
        })
        const maxHek = d3.max(data, function (d) {
            return +d.hek
        })

        var svg = d3.select("#chart2")

        var height = maxHkp; // сделать генерацию свг

        var yScaleAllHeihgt = d3.scaleLinear()
            .domain([d3.min(data, function (d) { return +d.hkp; }), d3.max(data, function (d) { return +d.height; })])
            .range([1, height + margin.top]);

        var y_axis = d3.axisRight()
            .scale(yScaleAllHeihgt)
            .ticks(30, "f")

        svg.append("g") // высота скважины 
            .attr("transform", "translate(180, 0)")
            .call(y_axis)
            .selectAll("text")
            .attr("dx", ".1em")
            .attr("dy", ".3em")
            .style("font-family", "Montserrat")
            .attr("transform", "rotate(0)")
            .style("font-size", "12px")
            .style("color", "white")

            var yScaleHek = d3.scaleLinear()
            .domain([d3.min(data, function (d) { return +d.hkp; }), d3.max(data, function (d) { return +d.hek; })])
            .range([margin.top + maxHkp, margin.top + maxHkp + maxHek]);

        var y_axisHek = d3.axisRight()
            .scale(yScaleHek)
            .ticks(2, "f")

        svg.append("g") // высота скважины 
            .attr("transform", "translate(150, 0)")
            .call(y_axisHek)
            .selectAll("text")
            .attr("dx", ".1em")
            .attr("dy", ".3em")
            .style("font-family", "Montserrat")
            .attr("transform", "rotate(0)")
            .style("font-size", "12px")
            .style("color", "white")

        for (var i = 0; i < data.length; i++) {
            svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return margin.top;
                })
                .attr("width", 90)
                .attr("height", function () {
                    return data[i].hkp;
                })
                .style("fill", "rgb(184, 110, 20")

            const hekrect = svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return margin.top + maxHkp;
                })
                .attr("width", 90)
                .attr("height", function () {
                    return data[i].hek;
                })
                .style("fill", "rgb(184, 110, 20")

            svg.append("rect")
                .attr("x", 60)
                .attr("y", 0)
                .attr("width", 30)
                .attr("height", function () {
                    return data[i].hnkt;
                })
                .style("fill", "rgb(184, 110, 20")

            svg.append("rect")
                .attr("x", 28)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 120)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")

            svg.append("rect")
                .attr("x", 150)
                .attr("y", 0)
                .attr("width", 2)
                .attr("height", function () {
                    return margin.top + maxHkp + maxHek;
                })
                .style("fill", "white")
        }

        svg.append("rect")
            .attr("x", 0)
            .attr("y", 0)
            .attr("width", 150)
            .attr("height", 2)
            .style("fill", "white")

        svg.append("rect")
            .attr("x", 0)
            .attr("y", margin.top + maxHkp + maxHek)
            .attr("width", 152)
            .attr("height", 3)
            .style("fill", "white")

        svg.append("rect")
            .attr("x", 30)
            .attr("y", margin.top + maxHkp + maxHek)
            .attr("width", 92)
            .attr("height", 20)
            .style("fill", "gray")

        for (var i = 1; i < data.length; i++) {
            var delay1 = i * 250; //hnkt зависит от колва данных, от кол ва массивов, у нас же прогоняется цикл, поэтому тут только меняя delay можно подогнать 1 время выполнения 
            var delay2 = i * 70; //hkp
            var delay3 = i * 100; //hek

            svg.append("rect")
                .attr("x", 60)
                .attr("y", function () {
                    return maxHnkt - data[i].hnktjg;
                })
                .attr("width", 30)
                .attr("height", 0)
                .style("stroke", "black")
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay1)
                .duration(500)
                .attr("height", function () {
                    return data[i].hnktjg;
                })

            svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return maxHnkt;
                })
                .attr("width", 90)
                .attr("height", 0)
                // .style("stroke", "black")
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay3)
                .duration(500)
                .attr("height", function () {
                    return data[i].hekjg;
                })

            svg.append("rect")
                .attr("x", 30)
                .attr("y", function () {
                    return;
                })
                .attr("width", 30)
                .attr("height", 0)
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay2)
                .duration(500)
                .attr("height", function () {
                    return data[i].hkpjg;
                })

            svg.append("rect")
                .attr("x", 90)
                .attr("y", function () {
                    return;
                })
                .attr("width", 30)
                .attr("height", 0)
                .style("fill", "rgb(11, 11, 100)")
                .transition()
                .delay(delay2)
                .duration(500)
                .attr("height", function () {
                    return data[i].hkpjg;
                })
        }
    }




data_for_direct = [{ 't': 0, 'hnkt': 1191.0932721712538, 'hkp': 1191.0932721712538, 'hek': 100.0, 'hnktjg': 0, 'hkpjg': 0, 'hekjg': 0, 'height': 1191.0932721712538 },
{ 't': 30, 'hnkt': 1191.0932721712538, 'hkp': 1191.0932721712538, 'hek': 100.0, 'hnktjg': 99.36833075456526, 'hkpjg': 0, 'hekjg': 0, 'height': 1191.0932721712538 },
{ 't': 60, 'hnkt': 1089.6030504613657, 'hkp': 1213.8134639045722, 'hek': 100.0, 'hnktjg': 198.73666150913053, 'hkpjg': 0, 'hekjg': 0, 'height': 1213.8134639045722 },
{ 't': 90, 'hnkt': 974.356666703196, 'hkp': 1222.777493589609, 'hek': 100.0, 'hnktjg': 298.1049922636958, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1222.777493589609 },
{ 't': 120, 'hnkt': 871.7176009465406, 'hkp': 1244.3488412761603, 'hek': 100.0, 'hnktjg': 397.47332301826106, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1244.3488412761603 },
{ 't': 150, 'hnkt': 769.7785974244869, 'hkp': 1266.620251197313, 'hek': 100.0, 'hnktjg': 496.8416537728263, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1266.620251197313 },
{ 't': 180, 'hnkt': 667.2124380727327, 'hkp': 1288.2645052887656, 'hek': 100.0, 'hnktjg': 596.2099845273916, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1288.2645052887656 },
{ 't': 210, 'hnkt': 564.621016243277, 'hkp': 1309.8834969025165, 'hek': 100.0, 'hnktjg': 695.5783152819569, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1309.8834969025165 },
{ 't': 240, 'hnkt': 462.06973036186594, 'hkp': 1331.542624464312, 'hek': 100.0, 'hnktjg': 794.9466460365221, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1331.542624464312 },
{ 't': 270, 'hnkt': 359.52804374980917, 'hkp': 1353.2113512954618, 'hek': 100.0, 'hnktjg': 894.3149767910874, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1353.2113512954618 },
{ 't': 300, 'hnkt': 256.9923299513355, 'hkp': 1374.8860509401948, 'hek': 100.0, 'hnktjg': 993.6833075456526, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1374.8860509401948 },
{ 't': 330, 'hnkt': 154.4636933334366, 'hkp': 1396.5678277655024, 'hek': 100.0, 'hnktjg': 1093.051638300218, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1396.5678277655024 },
{ 't': 360, 'hnkt': 33.68545212472736, 'hkp': 1400.0, 'hek': 100.0, 'hnktjg': 1192.4199690547832, 'hkpjg': 0.0, 'hekjg': 0.0, 'height': 1400.0 },
{ 't': 390, 'hnkt': 0.0, 'hkp': 1381.8513906603312, 'hek': 99.84941775561741, 'hnktjg': 1210.596122441438, 'hkpjg': 18.14860933966891, 'hekjg': 0.1505822443825891, 'height': 1400.0 },
{ 't': 420, 'hnkt': 0.0, 'hkp': 1363.5876264896394, 'hek': 100.32838253879518, 'hnktjg': 1228.7722758280927, 'hkpjg': 36.41237351036052, 'hekjg': -0.32838253879518536, 'height': 1400.0 },
{ 't': 450, 'hnkt': 0.0, 'hkp': 1345.593236964658, 'hek': 99.3346865052201, 'hnktjg': 1246.9484292147474, 'hkpjg': 54.40676303534202, 'hekjg': 0.6653134947798949, 'height': 1400.0 },
{ 't': 480, 'hnkt': 0.0, 'hkp': 1327.6006122050044, 'hek': 98.33134256754306, 'hnktjg': 1265.1245826014022, 'hkpjg': 72.39938779499552, 'hekjg': 1.6686574324569456, 'height': 1400.0 },
{ 't': 510, 'hnkt': 0.0, 'hkp': 1309.6068453578487, 'hek': 97.33424237826853, 'hnktjg': 1283.3007359880569, 'hkpjg': 90.39315464215129, 'hekjg': 2.6657576217314736, 'height': 1400.0 },
{ 't': 540, 'hnkt': 0.0, 'hkp': 1291.6119555338287, 'hek': 96.34328146027461, 'hnktjg': 1301.4768893747116, 'hkpjg': 108.38804446617124, 'hekjg': 3.6567185397253943, 'height': 1400.0 },
{ 't': 570, 'hnkt': 0.0, 'hkp': 1273.6159901406413, 'hek': 95.35820063750816, 'hnktjg': 1319.6530427613664, 'hkpjg': 126.3840098593587, 'hekjg': 4.641799362491837, 'height': 1400.0 },
{ 't': 600, 'hnkt': 0.0, 'hkp': 1255.6189934287593, 'hek': 94.37875799433762, 'hnktjg': 1337.829196148021, 'hkpjg': 144.38100657124073, 'hekjg': 5.6212420056623795, 'height': 1400.0 },
{ 't': 630, 'hnkt': 0.0, 'hkp': 1237.6210065024172, 'hek': 93.40472881549516, 'hnktjg': 1356.0053495346758, 'hkpjg': 162.37899349758274, 'hekjg': 6.595271184504833, 'height': 1400.0 },
{ 't': 660, 'hnkt': 0.0, 'hkp': 1219.6220676284634, 'hek': 92.43590389759453, 'hnktjg': 1374.1815029213305, 'hkpjg': 180.37793237153662, 'hekjg': 7.564096102405475, 'height': 1400.0 },
{ 't': 690, 'hnkt': 0.0, 'hkp': 1201.6222125096717, 'hek': 91.47208805494537, 'hnktjg': 1392.3576563079853, 'hkpjg': 198.37778749032822, 'hekjg': 8.52791194505463, 'height': 1400.0 },
{ 't': 720, 'hnkt': 0.0, 'hkp': 1179.5917245501128, 'hek': 90.51309880755652, 'hnktjg': 1400.0, 'hkpjg': 220.40827544988713, 'hekjg': 9.48690119244348, 'height': 1400.0 },
{ 't': 750, 'hnkt': 0.0, 'hkp': 1157.4947956734652, 'hek': 89.85089857872384, 'hnktjg': 1400.0, 'hkpjg': 242.50520432653474, 'hekjg': 10.149101421276155, 'height': 1400.0 },
{ 't': 780, 'hnkt': 0.0, 'hkp': 1135.25110008319, 'hek': 89.84429960891788, 'hnktjg': 1400.0, 'hkpjg': 264.7488999168099, 'hekjg': 10.155700391082119, 'height': 1400.0 },
{ 't': 810, 'hnkt': 0.0, 'hkp': 1113.0058839583753, 'hek': 89.84449280835851, 'hnktjg': 1400.0, 'hkpjg': 286.9941160416248, 'hekjg': 10.155507191641487, 'height': 1400.0 },
{ 't': 840, 'hnkt': 0.0, 'hkp': 1090.7606520809313, 'hek': 89.84475637418564, 'hnktjg': 1400.0, 'hkpjg': 309.23934791906873, 'hekjg': 10.155243625814368, 'height': 1400.0 },
{ 't': 870, 'hnkt': 0.0, 'hkp': 1068.5154200402162, 'hek': 89.84502066933912, 'hnktjg': 1400.0, 'hkpjg': 331.4845799597839, 'hekjg': 10.154979330660876, 'height': 1400.0 },
{ 't': 900, 'hnkt': 0.0, 'hkp': 1046.270187997734, 'hek': 89.84528497238682, 'hnktjg': 1400.0, 'hkpjg': 353.72981200226616, 'hekjg': 10.154715027613172, 'height': 1400.0 },
{ 't': 930, 'hnkt': 0.0, 'hkp': 1024.0249559551573, 'hek': 89.84554927585481, 'hnktjg': 1400.0, 'hkpjg': 375.9750440448426, 'hekjg': 10.1544507241452, 'height': 1400.0 },
{ 't': 960, 'hnkt': 0.0, 'hkp': 1001.7797239125042, 'hek': 89.84581357966562, 'hnktjg': 1400.0, 'hkpjg': 398.2202760874958, 'hekjg': 10.154186420334389, 'height': 1400.0 },
{ 't': 990, 'hnkt': 0.0, 'hkp': 979.5344918697745, 'hek': 89.84607788381847, 'hnktjg': 1400.0, 'hkpjg': 420.46550813022554, 'hekjg': 10.153922116181533, 'height': 1400.0 },
{ 't': 1020, 'hnkt': 0.0, 'hkp': 957.289259826968, 'hek': 89.84634218831334, 'hnktjg': 1400.0, 'hkpjg': 442.710740173032, 'hekjg': 10.153657811686658, 'height': 1400.0 },
{ 't': 1050, 'hnkt': 0.0, 'hkp': 935.0440277840853, 'hek': 89.84660649315026, 'hnktjg': 1400.0, 'hkpjg': 464.95597221591476, 'hekjg': 10.153393506849742, 'height': 1400.0 },
{ 't': 1080, 'hnkt': 0.0, 'hkp': 912.7987957411258, 'hek': 89.8468707983292, 'hnktjg': 1400.0, 'hkpjg': 487.2012042588742, 'hekjg': 10.15312920167079, 'height': 1400.0 },
{ 't': 1110, 'hnkt': 0.0, 'hkp': 890.5535636980898, 'hek': 89.8471351038502, 'hnktjg': 1400.0, 'hkpjg': 509.44643630191024, 'hekjg': 10.15286489614979, 'height': 1400.0 },
{ 't': 1140, 'hnkt': 0.0, 'hkp': 868.3083316549771, 'hek': 89.84739940971325, 'hnktjg': 1400.0, 'hkpjg': 531.6916683450229, 'hekjg': 10.152600590286749, 'height': 1400.0 },
{ 't': 1170, 'hnkt': 0.0, 'hkp': 846.0630996117878, 'hek': 89.84766371591834, 'hnktjg': 1400.0, 'hkpjg': 553.9369003882122, 'hekjg': 10.152336284081663, 'height': 1400.0 },
{ 't': 1200, 'hnkt': 0.0, 'hkp': 823.8178675685222, 'hek': 89.84792802246548, 'hnktjg': 1400.0, 'hkpjg': 576.1821324314778, 'hekjg': 10.152071977534519, 'height': 1400.0 },
{ 't': 1230, 'hnkt': 0.0, 'hkp': 801.5726355251797, 'hek': 89.84819232935467, 'hnktjg': 1400.0, 'hkpjg': 598.4273644748203, 'hekjg': 10.151807670645324, 'height': 1400.0 },
{ 't': 1260, 'hnkt': 0.0, 'hkp': 779.327403481761, 'hek': 89.84845663658594, 'hnktjg': 1400.0, 'hkpjg': 620.672596518239, 'hekjg': 10.151543363414065, 'height': 1400.0 },
{ 't': 1290, 'hnkt': 0.0, 'hkp': 757.0821714382654, 'hek': 89.84872094415925, 'hnktjg': 1400.0, 'hkpjg': 642.9178285617346, 'hekjg': 10.151279055840748, 'height': 1400.0 },
{ 't': 1320, 'hnkt': 0.0, 'hkp': 734.8369393946933, 'hek': 89.84898525207463, 'hnktjg': 1400.0, 'hkpjg': 665.1630606053067, 'hekjg': 10.15101474792537, 'height': 1400.0 },
{ 't': 1350, 'hnkt': 0.0, 'hkp': 712.5917073510448, 'hek': 89.84924956033208, 'hnktjg': 1400.0, 'hkpjg': 687.4082926489552, 'hekjg': 10.150750439667918, 'height': 1400.0 },
{ 't': 1380, 'hnkt': 0.0, 'hkp': 690.3464753073196, 'hek': 89.8495138689316, 'hnktjg': 1400.0, 'hkpjg': 709.6535246926804, 'hekjg': 10.1504861310684, 'height': 1400.0 },
{ 't': 1410, 'hnkt': 0.0, 'hkp': 668.101243263518, 'hek': 89.8497781778732, 'hnktjg': 1400.0, 'hkpjg': 731.898756736482, 'hekjg': 10.1502218221268, 'height': 1400.0 },
{ 't': 1440, 'hnkt': 0.0, 'hkp': 645.8560112196394, 'hek': 89.85004248715687, 'hnktjg': 1400.0, 'hkpjg': 754.1439887803606, 'hekjg': 10.149957512843129, 'height': 1400.0 },
{ 't': 1470, 'hnkt': 0.0, 'hkp': 623.6107791756845, 'hek': 89.85030679678262, 'hnktjg': 1400.0, 'hkpjg': 776.3892208243155, 'hekjg': 10.14969320321738, 'height': 1400.0 },
{ 't': 1500, 'hnkt': 0.0, 'hkp': 601.365547131653, 'hek': 89.85057110675046, 'hnktjg': 1400.0, 'hkpjg': 798.634452868347, 'hekjg': 10.149428893249542, 'height': 1400.0 },
{ 't': 1530, 'hnkt': 0.0, 'hkp': 579.1203150875449, 'hek': 89.85083541706038, 'hnktjg': 1400.0, 'hkpjg': 820.8796849124551, 'hekjg': 10.149164582939612, 'height': 1400.0 },
{ 't': 1560, 'hnkt': 0.0, 'hkp': 556.8750830433602, 'hek': 89.8510997277124, 'hnktjg': 1400.0, 'hkpjg': 843.1249169566398, 'hekjg': 10.148900272287605, 'height': 1400.0 },
{ 't': 1590, 'hnkt': 0.0, 'hkp': 534.629850999099, 'hek': 89.8513640387065, 'hnktjg': 1400.0, 'hkpjg': 865.370149000901, 'hekjg': 10.148635961293499, 'height': 1400.0 },
{ 't': 1620, 'hnkt': 0.0, 'hkp': 512.3846189547613, 'hek': 89.85162835004272, 'hnktjg': 1400.0, 'hkpjg': 887.6153810452387, 'hekjg': 10.148371649957289, 'height': 1400.0 },
{ 't': 1650, 'hnkt': 0.0, 'hkp': 490.13938691034673, 'hek': 89.85189266172101, 'hnktjg': 1400.0, 'hkpjg': 909.8606130896533, 'hekjg': 10.148107338278985, 'height': 1400.0 },
{ 't': 1680, 'hnkt': 0.0, 'hkp': 467.89415486585574, 'hek': 89.85215697374142, 'hnktjg': 1400.0, 'hkpjg': 932.1058451341443, 'hekjg': 10.147843026258581, 'height': 1400.0 },
{ 't': 1710, 'hnkt': 0.0, 'hkp': 445.6489228212881, 'hek': 89.85242128610393, 'hnktjg': 1400.0, 'hkpjg': 954.3510771787119, 'hekjg': 10.147578713896065, 'height': 1400.0 },
{ 't': 1740, 'hnkt': 0.0, 'hkp': 423.40369077664377, 'hek': 89.85268559880856, 'hnktjg': 1400.0, 'hkpjg': 976.5963092233562, 'hekjg': 10.147314401191434, 'height': 1400.0 },
{ 't': 1770, 'hnkt': 0.0, 'hkp': 401.15845873192336, 'hek': 89.85294991185529, 'hnktjg': 1400.0, 'hkpjg': 998.8415412680766, 'hekjg': 10.147050088144704, 'height': 1400.0 },
{ 't': 1800, 'hnkt': 0.0, 'hkp': 378.91322668712576, 'hek': 89.85321422524416, 'hnktjg': 1400.0, 'hkpjg': 1021.0867733128742, 'hekjg': 10.146785774755843, 'height': 1400.0 },
{ 't': 1830, 'hnkt': 0.0, 'hkp': 356.66799464225187, 'hek': 89.85347853897512, 'hnktjg': 1400.0, 'hkpjg': 1043.3320053577481, 'hekjg': 10.146521461024877, 'height': 1400.0 },
{ 't': 1860, 'hnkt': 0.0, 'hkp': 334.42276259730124, 'hek': 89.85374285304822, 'hnktjg': 1400.0, 'hkpjg': 1065.5772374026988, 'hekjg': 10.146257146951783, 'height': 1400.0 },
{ 't': 1890, 'hnkt': 0.0, 'hkp': 312.177530552274, 'hek': 89.85400716746344, 'hnktjg': 1400.0, 'hkpjg': 1087.822469447726, 'hekjg': 10.145992832536557, 'height': 1400.0 },
{ 't': 1920, 'hnkt': 0.0, 'hkp': 289.9322985071706, 'hek': 89.8542714822208, 'hnktjg': 1400.0, 'hkpjg': 1110.0677014928294, 'hekjg': 10.145728517779206, 'height': 1400.0 },
{ 't': 1950, 'hnkt': 0.0, 'hkp': 267.6870664619903, 'hek': 89.85453579732028, 'hnktjg': 1400.0, 'hkpjg': 1132.3129335380097, 'hekjg': 10.145464202679719, 'height': 1400.0 },
{ 't': 1980, 'hnkt': 0.0, 'hkp': 245.4418344167334, 'hek': 89.8548001127619, 'hnktjg': 1400.0, 'hkpjg': 1154.5581655832666, 'hekjg': 10.1451998872381, 'height': 1400.0 },
{ 't': 2010, 'hnkt': 0.0, 'hkp': 223.19660237139988, 'hek': 89.85506442854566, 'hnktjg': 1400.0, 'hkpjg': 1176.8033976286001, 'hekjg': 10.144935571454347, 'height': 1400.0 },
{ 't': 2040, 'hnkt': 0.0, 'hkp': 200.9513703259895, 'hek': 89.85532874467155, 'hnktjg': 1400.0, 'hkpjg': 1199.0486296740105, 'hekjg': 10.144671255328447, 'height': 1400.0 },
{ 't': 2070, 'hnkt': 0.0, 'hkp': 178.70613828050296, 'hek': 89.8555930611396, 'hnktjg': 1400.0, 'hkpjg': 1221.293861719497, 'hekjg': 10.144406938860397, 'height': 1400.0 },
{ 't': 2100, 'hnkt': 0.0, 'hkp': 156.46090623493956, 'hek': 89.8558573779498, 'hnktjg': 1400.0, 'hkpjg': 1243.5390937650604, 'hekjg': 10.144142622050204, 'height': 1400.0 },
{ 't': 2130, 'hnkt': 0.0, 'hkp': 134.21567418929976, 'hek': 89.85612169510213, 'hnktjg': 1400.0, 'hkpjg': 1265.7843258107002, 'hekjg': 10.143878304897862, 'height': 1400.0 },
{ 't': 2160, 'hnkt': 0.0, 'hkp': 111.97044214358334, 'hek': 89.85638601259663, 'hnktjg': 1400.0, 'hkpjg': 1288.0295578564167, 'hekjg': 10.143613987403363, 'height': 1400.0 },
{ 't': 2190, 'hnkt': 0.0, 'hkp': 89.72521009779007, 'hek': 89.8566503304333, 'hnktjg': 1400.0, 'hkpjg': 1310.27478990221, 'hekjg': 10.143349669566708, 'height': 1400.0 },
{ 't': 2220, 'hnkt': 0.0, 'hkp': 67.47997805192063, 'hek': 89.8569146486121, 'hnktjg': 1400.0, 'hkpjg': 1332.5200219480794, 'hekjg': 10.143085351387889, 'height': 1400.0 },
{ 't': 2250, 'hnkt': 0.0, 'hkp': 45.23474600597433, 'hek': 89.8571789671331, 'hnktjg': 1400.0, 'hkpjg': 1354.7652539940257, 'hekjg': 10.1428210328669, 'height': 1400.0 },
{ 't': 2280, 'hnkt': 0.0, 'hkp': 22.98951395995141, 'hek': 89.85744328599625, 'hnktjg': 1400.0, 'hkpjg': 1377.0104860400486, 'hekjg': 10.142556714003748, 'height': 1400.0 },
{ 't': 2310, 'hnkt': 0.0, 'hkp': 0.7442819138518644, 'hek': 89.85770760520157, 'hnktjg': 1400.0, 'hkpjg': 1399.2557180861481, 'hekjg': 10.14229239479843, 'height': 1400.0 },
{ 't': 2340, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.85797192474907, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142028075250932, 'height': 1400.0 },
{ 't': 2370, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.85798341458101, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.14201658541898, 'height': 1400.0 },
{ 't': 2400, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.85798353359209, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016466407915, 'height': 1400.0 },
{ 't': 2430, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348248, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465175196, 'height': 1400.0 },
{ 't': 2460, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.85798353483757, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162433, 'height': 1400.0 },
{ 't': 2490, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162305, 'height': 1400.0 },
{ 't': 2520, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2550, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2580, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2610, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2640, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2670, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2700, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2730, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 },
{ 't': 2760, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 89.8579835348377, 'hnktjg': 1400.0, 'hkpjg': 1400.0, 'hekjg': 10.142016465162294, 'height': 1400.0 }
];


data_for_back = [
    {
        't': 0, 'hnkt': 1191.0932721712538, 'hkp': 1191.0932721712538, 'hek': 100.0, 'hnktjg': 0, 'hkpjg': 0, 'hekjg': 0,
        'height': 1191.0932721712538
    },
    {
        't': 30, 'hnkt': 1191.0932721712538, 'hkp': 1191.0932721712538, 'hek': 100.0, 'hnktjg': 0,
        'hkpjg': 22.245172874063762, 'hekjg': 0, 'height': 1191.0932721712538
    },
    {
        't': 60, 'hnkt': 1213.8134639045722, 'hkp': 1186.0069978119925, 'hek': 100.0, 'hnktjg': 0,
        'hkpjg': 44.490345748127524, 'hekjg': 0, 'height': 1213.8134639045722
    },
    {
        't': 90, 'hnkt': 1233.45412113707, 'hkp': 1177.8411889519105, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 66.7355186221913, 'hekjg': 0.0, 'height': 1233.45412113707
    },
    {
        't': 120, 'hnkt': 1254.3663214820237, 'hkp': 1170.9469232042848, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 88.98069149625505, 'hekjg': 0.0, 'height': 1254.3663214820237
    },
    {
        't': 150, 'hnkt': 1275.6581300775472, 'hkp': 1164.4322657072285, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 111.22586437031882, 'hekjg': 0.0, 'height': 1275.6581300775472
    },
    {
        't': 180, 'hnkt': 1296.9371769586585, 'hkp': 1157.90484649576, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 133.4710372443826, 'hekjg': 0.0, 'height': 1296.9371769586585
    },
    {
        't': 210, 'hnkt': 1318.254462994904, 'hkp': 1151.4156664394259, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 155.71621011844636, 'hekjg': 0.0, 'height': 1318.254462994904
    },
    {
        't': 240, 'hnkt': 1339.6236109933861, 'hkp': 1144.9783483453282, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 177.9613829925101, 'hekjg': 0.0, 'height': 1339.6236109933861
    },
    {
        't': 270, 'hnkt': 1361.031674842469, 'hkp': 1138.5799461018314, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 200.20655586657386, 'hekjg': 0.0, 'height': 1361.031674842469
    },
    {
        't': 300, 'hnkt': 1382.4711811643003, 'hkp': 1132.212986331083, 'hek': 100.0, 'hnktjg': 0.0,
        'hkpjg': 222.45172874063763, 'hekjg': 0.0, 'height': 1382.4711811643003
    },
    {
        't': 330, 'hnkt': 1400.0, 'hkp': 1121.935339074203, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 244.6969016147014,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 360, 'hnkt': 1400.0, 'hkp': 1094.1288729816233, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 266.9420744887652,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 390, 'hnkt': 1400.0, 'hkp': 1066.3224068890436, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 289.1872473628289,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 420, 'hnkt': 1400.0, 'hkp': 1038.5159407964638, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 311.4324202368927,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 450, 'hnkt': 1400.0, 'hkp': 1010.7094747038841, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 333.6775931109564,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 480, 'hnkt': 1400.0, 'hkp': 982.9030086113045, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 355.9227659850202,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 510, 'hnkt': 1400.0, 'hkp': 955.0965425187247, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 378.167938859084,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 540, 'hnkt': 1400.0, 'hkp': 927.290076426145, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 400.41311173314773,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 570, 'hnkt': 1400.0, 'hkp': 899.4836103335654, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 422.6582846072115,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 600, 'hnkt': 1400.0, 'hkp': 871.6771442409856, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 444.90345748127527,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 630, 'hnkt': 1400.0, 'hkp': 843.8706781484059, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 467.148630355339,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 660, 'hnkt': 1400.0, 'hkp': 816.0642120558263, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 489.3938032294028,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 690, 'hnkt': 1400.0, 'hkp': 788.2577459632464, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 511.6389761034666,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 720, 'hnkt': 1400.0, 'hkp': 760.4512798706668, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 533.8841489775303,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 750, 'hnkt': 1400.0, 'hkp': 732.6448137780872, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 556.1293218515941,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 780, 'hnkt': 1400.0, 'hkp': 704.8383476855074, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 578.3744947256578,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 810, 'hnkt': 1400.0, 'hkp': 677.0318815929277, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 600.6196675997215,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 840, 'hnkt': 1400.0, 'hkp': 649.225415500348, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 622.8648404737854,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 870, 'hnkt': 1400.0, 'hkp': 621.4189494077683, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 645.1100133478492,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 900, 'hnkt': 1400.0, 'hkp': 593.6124833151885, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 667.3551862219128,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 930, 'hnkt': 1400.0, 'hkp': 565.806017222609, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 689.6003590959767,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 960, 'hnkt': 1400.0, 'hkp': 537.9995511300292, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 711.8455319700404,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 990, 'hnkt': 1400.0, 'hkp': 510.19308503744946, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 734.0907048441042,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1020, 'hnkt': 1400.0, 'hkp': 482.38661894486984, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 756.335877718168,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1050, 'hnkt': 1400.0, 'hkp': 454.58015285229, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 778.5810505922317,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1080, 'hnkt': 1400.0, 'hkp': 426.77368675971036, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 800.8262234662955,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1110, 'hnkt': 1400.0, 'hkp': 398.96722066713073, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 823.0713963403592,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1140, 'hnkt': 1400.0, 'hkp': 371.160754574551, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 845.316569214423,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1170, 'hnkt': 1400.0, 'hkp': 343.35428848197125, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 867.5617420884868,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1200, 'hnkt': 1400.0, 'hkp': 315.5478223893915, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 889.8069149625505,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1230, 'hnkt': 1400.0, 'hkp': 287.7413562968118, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 912.0520878366143,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1260, 'hnkt': 1400.0, 'hkp': 259.93489020423226, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 934.297260710678,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1290, 'hnkt': 1400.0, 'hkp': 232.12842411165252, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 956.5424335847418,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1320, 'hnkt': 1400.0, 'hkp': 204.32195801907278, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 978.7876064588056,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1350, 'hnkt': 1400.0, 'hkp': 176.5154919264928, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1001.0327793328693,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1380, 'hnkt': 1400.0, 'hkp': 148.7090258339133, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1023.2779522069332,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1410, 'hnkt': 1400.0, 'hkp': 120.90255974133356, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1045.5231250809968,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1440, 'hnkt': 1400.0, 'hkp': 93.09609364875405, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1067.7682979550607,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1470, 'hnkt': 1400.0, 'hkp': 65.28962755617431, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1090.0134708291243,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1500, 'hnkt': 1400.0, 'hkp': 37.48316146359434, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1112.2586437031882,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1530, 'hnkt': 1400.0, 'hkp': 9.67669537101483, 'hek': 100.0, 'hnktjg': 0.0, 'hkpjg': 1134.5038165772519,
        'hekjg': 0.0, 'height': 1400.0
    },
    {
        't': 1560, 'hnkt': 1381.823528107789, 'hkp': 0.0, 'hek': 100.0003898080642, 'hnktjg': 18.17647189221115,
        'hkpjg': 1152.680288469463, 'hekjg': -0.0003898080642001097, 'height': 1400.0
    },
    {
        't': 1590, 'hnkt': 1364.1955322602716, 'hkp': 0.0, 'hek': 99.3295185317858, 'hnktjg': 35.80446773972837,
        'hkpjg': 1170.3082843169802, 'hekjg': 0.6704814682142047, 'height': 1400.0
    },
    {
        't': 1620, 'hnkt': 1346.945422410248, 'hkp': 0.0, 'hek': 98.19616549921346, 'hnktjg': 53.05457758975205,
        'hkpjg': 1187.5583941670038, 'hekjg': 1.803834500786531, 'height': 1400.0
    },
    {
        't': 1650, 'hnkt': 1329.6667656807033, 'hkp': 0.0, 'hek': 97.09775001676225, 'hnktjg': 70.33323431929671,
        'hkpjg': 1204.8370508965486, 'hekjg': 2.9022499832377537, 'height': 1400.0
    },
    {
        't': 1680, 'hnkt': 1312.3769772507706, 'hkp': 0.0, 'hek': 96.01295824193761, 'hnktjg': 87.62302274922948,
        'hkpjg': 1222.1268393264813, 'hekjg': 3.987041758062385, 'height': 1400.0
    },
    {
        't': 1710, 'hnkt': 1295.0763945718136, 'hkp': 0.0, 'hek': 94.94137717954939, 'hnktjg': 104.92360542818636,
        'hkpjg': 1239.4274220054383, 'hekjg': 5.058622820450606, 'height': 1400.0
    },
    {
        't': 1740, 'hnkt': 1277.7658827055689, 'hkp': 0.0, 'hek': 93.8819481101059, 'hnktjg': 122.23411729443126,
        'hkpjg': 1256.7379338716833, 'hekjg': 6.118051889894103, 'height': 1400.0
    },
    {
        't': 1770, 'hnkt': 1260.4461709032332, 'hkp': 0.0, 'hek': 92.83377852799259, 'hnktjg': 139.55382909676672,
        'hkpjg': 1274.0576456740187, 'hekjg': 7.16622147200741, 'height': 1400.0
    },
    {
        't': 1800, 'hnkt': 1243.1178988652462, 'hkp': 0.0, 'hek': 91.79608552570689, 'hnktjg': 156.88210113475384,
        'hkpjg': 1291.3859177120057, 'hekjg': 8.20391447429311, 'height': 1400.0
    },
    {
        't': 1830, 'hnkt': 1225.7816310303035, 'hkp': 0.0, 'hek': 90.76817830602064, 'hnktjg': 174.21836896969643,
        'hkpjg': 1308.7221855469484, 'hekjg': 9.231821693979356, 'height': 1400.0
    },
    {
        't': 1860, 'hnkt': 1208.4378687083943, 'hkp': 0.0, 'hek': 89.74944333277344, 'hnktjg': 191.56213129160568,
        'hkpjg': 1326.0659478688576, 'hekjg': 10.250556667226558, 'height': 1400.0
    },
    {
        't': 1890, 'hnkt': 1191.0870597561748, 'hkp': 0.0, 'hek': 88.73933248951127, 'hnktjg': 208.91294024382515,
        'hkpjg': 1343.4167568210771, 'hekjg': 11.26066751048873, 'height': 1400.0
    },
    {
        't': 1920, 'hnkt': 1173.7296064054597, 'hkp': 0.0, 'hek': 87.7373534984644, 'hnktjg': 226.2703935945404,
        'hkpjg': 1360.7742101717924, 'hekjg': 12.262646501535604, 'height': 1400.0
    },
    {
        't': 1950, 'hnkt': 1156.3658716601535, 'hkp': 0.0, 'hek': 86.74306209156066, 'hnktjg': 243.63412833984646,
        'hkpjg': 1378.1379449170986, 'hekjg': 13.256937908439347, 'height': 1400.0
    },
    {
        't': 1980, 'hnkt': 1138.9961845713087, 'hkp': 0.0, 'hek': 85.75605555446494, 'hnktjg': 261.0038154286914,
        'hkpjg': 1395.5076320059436, 'hekjg': 14.24394444553506, 'height': 1400.0
    },
    {
        't': 2010, 'hnkt': 1044.0058700538698, 'hkp': 0.0, 'hek': 84.77596735834848, 'hnktjg': 355.9941299461303,
        'hkpjg': 1400.0, 'hekjg': 15.224032641651522, 'height': 1400.0
    },
    {
        't': 2040, 'hnkt': 945.7480332480689, 'hkp': 0.0, 'hek': 84.52736571959404, 'hnktjg': 454.25196675193115,
        'hkpjg': 1400.0, 'hekjg': 15.472634280405957, 'height': 1400.0
    },
    {
        't': 2070, 'hnkt': 846.3379510309993, 'hkp': 0.0, 'hek': 84.53671244499571, 'hnktjg': 553.6620489690007,
        'hkpjg': 1400.0, 'hekjg': 15.463287555004293, 'height': 1400.0
    },
    {
        't': 2100, 'hnkt': 746.9144583126887, 'hkp': 0.0, 'hek': 84.54906132325762, 'hnktjg': 653.0855416873113,
        'hkpjg': 1400.0, 'hekjg': 15.450938676742384, 'height': 1400.0
    },
    {
        't': 2130, 'hnkt': 647.4908048363825, 'hkp': 0.0, 'hek': 84.56144618974005, 'hnktjg': 752.5091951636175,
        'hkpjg': 1400.0, 'hekjg': 15.43855381025995, 'height': 1400.0
    },
    {
        't': 2160, 'hnkt': 548.0671447628786, 'hkp': 0.0, 'hek': 84.5738325331098, 'hnktjg': 851.9328552371214,
        'hkpjg': 1400.0, 'hekjg': 15.426167466890208, 'height': 1400.0
    },
    {
        't': 2190, 'hnkt': 448.64347988316194, 'hkp': 0.0, 'hek': 84.58621995242606, 'hnktjg': 951.356520116838,
        'hkpjg': 1400.0, 'hekjg': 15.413780047573944, 'height': 1400.0
    },
    {
        't': 2220, 'hnkt': 349.21981021521356, 'hkp': 0.0, 'hek': 84.59860844366399, 'hnktjg': 1050.7801897847864,
        'hkpjg': 1400.0, 'hekjg': 15.40139155633601, 'height': 1400.0
    },
    {
        't': 2250, 'hnkt': 249.7961357563754, 'hkp': 0.0, 'hek': 84.6109980074184, 'hnktjg': 1150.2038642436246,
        'hkpjg': 1400.0, 'hekjg': 15.389001992581592, 'height': 1400.0
    },
    {
        't': 2280, 'hnkt': 150.37245650374598, 'hkp': 0.0, 'hek': 84.62338864433859, 'hnktjg': 1249.627543496254,
        'hkpjg': 1400.0, 'hekjg': 15.376611355661415, 'height': 1400.0
    },
    {
        't': 2310, 'hnkt': 50.94877245442035, 'hkp': 0.0, 'hek': 84.6357803550751, 'hnktjg': 1349.0512275455796,
        'hkpjg': 1400.0, 'hekjg': 15.364219644924903, 'height': 1400.0
    },
    {
        't': 2340, 'hnkt': -48.47491639450982, 'hkp': 0.0, 'hek': 84.64817314027928, 'hnktjg': 1448.4749163945098,
        'hkpjg': 1400.0, 'hekjg': 15.351826859720724, 'height': 1400.0
    },
    {
        't': 2370, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.66056700060311, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.339432999396895, 'height': 1400.0
    },
    {
        't': 2400, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65472830124077, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.34527169875923, 'height': 1400.0
    },
    {
        't': 2430, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466352057838, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.34533647942162, 'height': 1400.0
    },
    {
        't': 2460, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466280183401, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337198165996, 'height': 1400.0
    },
    {
        't': 2490, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.6546627938595, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206140501, 'height': 1400.0
    },
    {
        't': 2520, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377102, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.34533720622898, 'height': 1400.0
    },
    {
        't': 2550, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377004, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229958, 'height': 1400.0
    },
    {
        't': 2580, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2610, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2640, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2670, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2700, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2730, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    },
    {
        't': 2760, 'hnkt': 0.0, 'hkp': 0.0, 'hek': 84.65466279377003, 'hnktjg': 1400.0, 'hkpjg': 1400.0,
        'hekjg': 15.345337206229969, 'height': 1400.0
    }]


direct_animation(data_for_direct);
back_animation(data_for_back);